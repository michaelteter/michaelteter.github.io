# TradeStats

This project demonstrates how a list of trades for one day can be processed, recording metrics for each stock symbol.

See [Instructions](instructions.txt)

## Usage with local file

Run trade aggregator

```bash
cat static/input.csv | mix run bin/day_trade_aggregator.exs > output.csv
```

## Usage with remotely sourced data

Start http file server

```bash
elixir bin/file_server.exs
```

Run trade aggregator in new terminal

```bash
# using sample data from instructions.txt, with known results
# output to STDOUT
curl -s http://localhost:8080/sample.csv | mix run bin/day_trade_aggregator.exs
```

```bash
# using "official" provided input data, and write results to output.csv
curl -s http://localhost:8080/input.csv | mix run bin/day_trade_aggregator.exs > output.csv
```

## Unit Testing

Run unit tests

```bash
mix test
```

## Project Structure

The overall structure is based on the `mix new` application generator. As such, there are some familiar directories such as `bin`, `lib`, and `test`.

Primary application code is in modules in the `lib` directory. However, there are some minimal _driver_ Elixir scripts in the `bin` directory. `test` has the usual unit test modules.

Additionally, the `static` directory contains some input files; and the associated "file server" http server is designed to fetch and provide files from this directory.

```text
.
├── README.md
├── _build
│   ├── dev
│   └── test
├── bin
│   ├── day_trade_aggregator.exs
│   └── file_server.exs
├── deps
│   └── nimble_csv
├── instructions.txt
├── lib
│   ├── symbol_aggregator.ex
│   └── trade_stats.ex
├── mix.exs
├── mix.lock
├── static
│   ├── input.csv
│   └── sample.csv
└── test
    ├── symbol_aggregator_test.exs
    ├── test_helper.exs
    └── trade_stats_test.exs
```

## Future Considerations

As currently built, this solution should be able to process input data of virtually any size - well beyond what the local disk/memory storage could hold.

The only limitation with this implementation is that the number of symbols being traded in one day is not so vast that the intermediate aggregate data is too large for local memory. However, given the small amount of data being stored per symbol, and the assumption that the total number of possible symbols should be < 100,000 (for example), the runtime memory footprint shouldn't be a concern.

If it were an actual concern, one solution would be to rely on something like Redis on a bigger server rather than a process-local map. Or we could use a local database, such as sqlite, as our key/value store instead of a local map.

### Scaling Up

The current SymbolAggregator module could easily be turned into a GenServer. This by itself wouldn't provide any real gains.

However, we could modify it so it is designed to only maintain aggregate data for a single symbol. Then our driver, the code which is receiving the stream of trades, could dispatch each trade to a symbol-specfic GenServer for processing and state management.

This would essentially allow us to parallelize massively, also distributing the memory load. Performance would still be limited by the incoming stream and router.
