defmodule SymbolAggregator do
  def aggregate([ts, symbol, qty, price], stats) do
    {ts, _} = Integer.parse(ts)
    {qty, _} = Integer.parse(qty)
    {price, _} = Integer.parse(price)

    default_stats = %{prev_ts: -1, max_ts_gap: 0, total_qty: 0, max_price: 0, n: 0}

    %{prev_ts: prev_ts, max_ts_gap: max_ts_gap, total_qty: total_qty, max_price: max_price, n: n} =
      Map.get(stats, symbol, default_stats)

    symbol_stats = %{
      prev_ts: ts,
      max_ts_gap: ts_gap(ts, prev_ts, max_ts_gap),
      total_qty: total_qty + qty,
      max_price: max(max_price, price),
      n: n + qty * price
    }

    Map.put(stats, symbol, symbol_stats)
  end

  def weighted_avg_price({symbol, symbol_stats}) do
    n = Map.get(symbol_stats, :n)
    total_qty = Map.get(symbol_stats, :total_qty)
    {symbol, Map.put(symbol_stats, :weighted_avg_price, trunc(n / total_qty))}
  end

  defp ts_gap(ts, prev_ts, max_ts_gap) do
    cond do
      prev_ts < 0 -> 0
      max_ts_gap == 0 -> ts - prev_ts
      true -> max(ts - prev_ts, max_ts_gap)
    end
  end
end
