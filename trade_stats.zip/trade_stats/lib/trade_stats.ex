defmodule TradeStats do
  alias NimbleCSV.RFC4180, as: CSV
  alias SymbolAggregator, as: SA

  @moduledoc """
  Documentation for `TradeStats`.
  """

  @doc """
  Aggregate trades, by symbol, for one day.
  """
  def aggregate_day_trades(trades_stream) do
    stats =
      trades_stream
      |> CSV.parse_stream(skip_headers: false)
      |> Enum.reduce(%{}, &SA.aggregate/2)
      |> Enum.map(&SA.weighted_avg_price/1)

    stats
    |> Enum.sort()
    |> Enum.map(&to_csv_row/1)
    |> Enum.each(&IO.write/1)
  end

  defp to_csv_row({symbol, symbol_stats}) do
    %{
      max_ts_gap: max_ts_gap,
      total_qty: total_qty,
      weighted_avg_price: weighted_avg_price,
      max_price: max_price
    } = symbol_stats

    "#{symbol},#{max_ts_gap},#{total_qty},#{weighted_avg_price},#{max_price}\n"
  end
end
