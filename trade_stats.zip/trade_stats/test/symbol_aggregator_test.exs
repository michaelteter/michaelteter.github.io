defmodule SymbolAggregatorTest do
  use ExUnit.Case
  doctest SymbolAggregator

  test "determines timestamp gap with no previous trades" do
    trade1 = ~w(123 a 10 45)

    stats = SymbolAggregator.aggregate(trade1, %{})

    assert stats["a"][:max_ts_gap] == 0
  end

  test "determines timestamp gap with no gap history" do
    trade1 = ~w(150 a 10 45)
    trade2 = ~w(200 a 8 50)

    stats = SymbolAggregator.aggregate(trade1, %{})
    stats = SymbolAggregator.aggregate(trade2, stats)

    assert stats["a"][:max_ts_gap] == 50
  end

  test "determines timestamp gap with gap history" do
    trade1 = ~w(150 a 10 45)
    trade2 = ~w(200 a 8 50)
    trade3 = ~w(210 a 11 51)

    stats = SymbolAggregator.aggregate(trade1, %{})
    stats = SymbolAggregator.aggregate(trade2, stats)
    stats = SymbolAggregator.aggregate(trade3, stats)

    assert stats["a"][:max_ts_gap] == 50

    trade4 = ~w(410 a 10 52)
    stats = SymbolAggregator.aggregate(trade4, stats)

    assert stats["a"][:max_ts_gap] == 200
  end

  test "calculates weighted price average for one trade" do
    symbol_stats = %{n: 10 * 45, total_qty: 10}

    {_, symbol_stats} =
      SymbolAggregator.weighted_avg_price({"a", symbol_stats})

    assert symbol_stats[:weighted_avg_price] == 45
  end

  test "calculates weighted price average for multiple trades" do
    trade1 = ~w(52924702 aaa 13 1136)
    trade2 = ~w(52930489 aaa 18 1222)
    trade3 = ~w(52931654 aaa 9 1078)

    stats = SymbolAggregator.aggregate(trade1, %{})
    stats = SymbolAggregator.aggregate(trade2, stats)
    stats = SymbolAggregator.aggregate(trade3, stats)

    {_, symbol_stats} =
      SymbolAggregator.weighted_avg_price({"aaa", stats["aaa"]})

    assert symbol_stats[:weighted_avg_price] == 1161
  end
end
