defmodule TradeStatsTest do
  use ExUnit.Case
  doctest TradeStats
end
